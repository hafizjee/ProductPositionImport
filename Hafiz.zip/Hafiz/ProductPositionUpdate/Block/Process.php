<?php
namespace Hafiz\ProductPositionUpdate\Block;

use Magento\Framework\View\Element\Template;
use Magento\Catalog\Api\ProductRepositoryInterface;
use Magento\Catalog\Api\CategoryLinkManagementInterface;
use Magento\Catalog\Model\CategoryFactory;
use Psr\Log\LoggerInterface;

class Process extends \Magento\Framework\View\Element\Template
{
    protected $productRepository;
    protected $categoryLinkManagement;
    protected $categoryFactory;
    protected $logger;

    public function __construct(
        Template\Context $context,
        ProductRepositoryInterface $productRepository,
        CategoryLinkManagementInterface $categoryLinkManagement,
        CategoryFactory $categoryFactory,
        LoggerInterface $logger, // Inject LoggerInterface
        array $data = []
    ) {
        parent::__construct($context, $data);
        $this->productRepository = $productRepository;
        $this->categoryLinkManagement = $categoryLinkManagement;
        $this->categoryFactory = $categoryFactory;
        $this->logger = $logger; // Assign to class property
    }

    public function _prepareLayout()
    {
        $this->requestValidation();
        $this->processCSV();
        return parent::_prepareLayout();
    }

    public function requestValidation()
    {
        if (!isset($_FILES['csv_file']) || $_FILES['csv_file']['error'] || !$_FILES['csv_file']['tmp_name']) {
            die("Invalid file upload");
        }
    }

    public function processCSV()
    {
        $file = fopen($_FILES['csv_file']['tmp_name'], "r");
        $header = fgetcsv($file);

        // Validate CSV headers
        if ($header[0] !== 'CategoryID' || $header[1] !== 'ProductID' || $header[2] !== 'PositionInCategory') {
            die("CSV should contain headers: CategoryID, ProductID, and PositionInCategory");
        }

        while (($row = fgetcsv($file)) !== false) {
            list($categoryId, $productId, $position) = $row;
            try {
                // Update the product position within the category
                $this->updateProductPositionInCategory([$categoryId], $productId, $position);
            } catch (\Exception $e) {
                // Log error using Magento's core logger
                $this->logger->error('Error processing product: ' . $productId . ' - ' . $e->getMessage());
            }
        }

        fclose($file);
    }

    /**
     * Change product position within the specified categories
     *
     * @param array $categoryIds
     * @param int $productId
     * @param int $position
     */
    public function updateProductPositionInCategory(array $categoryIds, $productId, $position)
    {
        foreach ($categoryIds as $categoryId) {
            try {
                $category = $this->categoryFactory->create()->load($categoryId);
                $products = $category->getProductsPosition();
                $products[$productId] = $position;
                $category->setPostedProducts($products);
                $category->save();
                // Log success using Magento's core logger
                $this->logger->info('Updated position for Product ID: ' . $productId . ' in Category ID: ' . $categoryId . ' to Position: ' . $position);
            } catch (\Exception $e) {
                // Log error using Magento's core logger
                $this->logger->error('Error updating position for Product ID: ' . $productId . ' in Category ID: ' . $categoryId . ' - ' . $e->getMessage());
            }
        }
    }
}
