<?php
namespace Hafiz\ProductPositionUpdate\Controller\Adminhtml\Update;

use Magento\Backend\App\Action;
use Magento\Framework\View\Result\PageFactory;
use Hafiz\ProductPositionUpdate\Block\Process as ProcessBlock;

class Process extends Action
{
    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @var ProcessBlock
     */
    protected $processBlock;

    /**
     * Constructor
     *
     * @param Action\Context $context
     * @param PageFactory $resultPageFactory
     * @param ProcessBlock $processBlock
     */
    public function __construct(
        Action\Context $context,
        PageFactory $resultPageFactory,
        ProcessBlock $processBlock
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
        $this->processBlock = $processBlock;
    }

    /**
     * Execute function to process the CSV and display a success message.
     *
     * @return \Magento\Framework\Controller\Result\Redirect
     */
    public function execute()
    {
        try {
            $this->processBlock->processCSV();
            $this->messageManager->addSuccessMessage(__('Product positions updated successfully.'));
        } catch (\Exception $e) {
            $this->messageManager->addErrorMessage(__('An error occurred while processing the CSV: %1', $e->getMessage()));
        }
        return $this->resultRedirectFactory->create()->setPath('*/*/');
    }
}
